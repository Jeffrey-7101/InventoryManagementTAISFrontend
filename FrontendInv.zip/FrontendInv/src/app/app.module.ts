import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';  // Asegúrate de importar FormsModule
import { RouterModule } from '@angular/router';
import { HttpClientModule, provideHttpClient } from '@angular/common/http'; // Necesario para HttpClient
import { AppComponent } from './app.component';
import { ProductTableComponent } from './product-table/product-table.component';
import { HeaderComponent } from './header/header.component';
import { ProductFormComponent } from './product-form/product-form.component';
import { DeleteConfirmationComponent } from './delete-confirmation/delete-confirmation.component';
import { withFetch } from '@angular/common/http';
import { IngresosComponent } from './ingresos/ingresos.component';
import { SalidasComponent } from './salidas/salidas.component';
import { routes } from './app.routes';  // Importa el archivo de rutas


@NgModule({
  declarations: [
    // Declaraciones solo si usas componentes tradicionales
    AppComponent,
    ProductTableComponent,
    HeaderComponent,
    ProductFormComponent,
    DeleteConfirmationComponent,
    IngresosComponent,
    SalidasComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(routes),
    FormsModule,
    HttpClientModule
    // Registra tus componentes standalone aquí si los mantienes como standalone
  ],
  providers: [
    // Habilitar la API fetch para Server-Side Rendering
    provideHttpClient(withFetch())
  ],
  schemas: [NO_ERRORS_SCHEMA],
  bootstrap: [AppComponent], // Componente raíz que inicializa la aplicación
})
export class AppModule {}
