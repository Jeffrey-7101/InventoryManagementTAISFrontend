import { Component, OnInit} from '@angular/core';
import { CommonModule } from '@angular/common'; // Importar CommonModule
import { DeleteConfirmationComponent } from '../delete-confirmation/delete-confirmation.component';
import { HeaderIngresosComponent } from '../header-ingresos/header-ingresos.component';
import { HeaderComponent } from '../header/header.component';
import { HeaderSalidasComponent } from '../header-salidas/header-salidas.component';

@Component({
  selector: 'app-salidas',
  standalone: true,
  templateUrl: './salidas.component.html',
  styleUrls: ['./salidas.component.css'],
  imports: [
    CommonModule, // Asegurarse de incluir CommonModule
    DeleteConfirmationComponent,
    HeaderIngresosComponent,
    HeaderComponent,
    HeaderSalidasComponent,
  ],
})
export class SalidasService implements OnInit {
  salidas: any[] = [];
  deleteMessage: string = '';
  salidaAEliminar: number | null = null;

  constructor(private salidaService: SalidasService) {}

  ngOnInit(): void {
    this.cargarSalidas();
  }

  getSalidas() {
    this.salidaService.getSalidas().subscribe(
      (data: any) => {  // Especifica el tipo para 'data'
        console.log(data);
        // Procesar los datos
      },
      (error: any) => {  // Especifica el tipo para 'error'
        console.error('Error en la solicitud', error);
      }
    );
  }
  

  cargarSalidas() {
    this.salidaService.getAllNotas().subscribe(
      (data) => {
        this.salidas = data;
      },
      (error) => {
        console.error('Error al cargar las salidas:', error);
      }
    );
  }

  agregarNota(nota: any) {
    this.salidaService.createNota(nota).subscribe(
      (response) => {
        alert('Nota creada exitosamente.');
        this.cargarSalidas(); // Recargar las notas
      },
      (error) => {
        console.error('Error al crear nota:', error);
      }
    );
  }

  eliminarNota(id: string) {
    this.salidaService.deleteNota(id).subscribe(
      () => {
        alert('Nota eliminada exitosamente.');
        this.cargarSalidas(); // Recargar las notas
      },
      (error) => {
        console.error('Error al eliminar nota:', error);
      }
    );
  }

  openDeleteConfirmation(id: number) {
    this.salidaAEliminar = id;
    this.deleteMessage = `¿Está seguro de que desea eliminar la nota de salida con ID "${id}"?`;
  }

  onDeleteConfirmed() {
    if (this.salidaAEliminar !== null) {
      this.eliminarNota(this.salidaAEliminar.toString());
      this.salidaAEliminar = null;
    }
  }
}
