import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class SalidaService {
  private apiBaseUrl = 'https://s2nzokwsie.execute-api.us-east-1.amazonaws.com/dev/outbound-notes';

  constructor(private http: HttpClient) {}

  // Obtener todas las notas de salida
  getAllNotas(): Observable<any> {
    return this.http.get(`${this.apiBaseUrl}`);
  }

  // Obtener una nota de salida por ID
  getNotaById(noteId: string): Observable<any> {
    return this.http.get(`${this.apiBaseUrl}/${noteId}`);
  }

  // Crear una nueva nota de salida
  createNota(nota: any): Observable<any> {
    return this.http.post(`${this.apiBaseUrl}`, nota);
  }

  // Actualizar una nota de salida existente
  updateNota(noteId: string, nota: any): Observable<any> {
    return this.http.put(`${this.apiBaseUrl}/${noteId}`, nota);
  }

  // Eliminar una nota de salida por ID
  deleteNota(noteId: string): Observable<any> {
    return this.http.delete(`${this.apiBaseUrl}/${noteId}`);
  }

  // Obtener el archivo relacionado con una nota de salida
  getNotaFile(noteId: string): Observable<any> {
    return this.http.get(`${this.apiBaseUrl}/${noteId}/file`, { responseType: 'blob' });
  }
}
